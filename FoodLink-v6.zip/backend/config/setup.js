require("dotenv").config();
const mysql = require("mysql2/promise");
const bcrypt = require("bcryptjs");

async function setup() {
  let conn;
  try {
    // Step 1: Connect without DB to create it
    conn = await mysql.createConnection({
      host: process.env.DB_HOST || "localhost",
      port: process.env.DB_PORT || 3306,
      user: process.env.DB_USER || "root",
      password: process.env.DB_PASSWORD || "",
    });

    await conn.query(`CREATE DATABASE IF NOT EXISTS \`${process.env.DB_NAME || "foodlink_db"}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);
    await conn.query(`USE \`${process.env.DB_NAME || "foodlink_db"}\``);
    console.log("✅ Database created/selected");

    // ── USERS ─────────────────────────────────────────────────────────────────
    await conn.query(`
      CREATE TABLE IF NOT EXISTS users (
        id          INT AUTO_INCREMENT PRIMARY KEY,
        uuid        VARCHAR(36) NOT NULL UNIQUE,
        full_name   VARCHAR(100) NOT NULL,
        email       VARCHAR(150) NOT NULL UNIQUE,
        phone       VARCHAR(20),
        password    VARCHAR(255) NOT NULL,
        role        ENUM('donor','volunteer','recipient','admin') NOT NULL DEFAULT 'donor',
        donor_type  VARCHAR(50),
        address     TEXT,
        city        VARCHAR(100),
        profile_image VARCHAR(255),
        is_active   TINYINT(1) DEFAULT 1,
        is_verified TINYINT(1) DEFAULT 0,
        otp_code    VARCHAR(10),
        otp_expiry  DATETIME,
        reset_token VARCHAR(100),
        reset_expiry DATETIME,
        last_login  DATETIME,
        created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at  DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      ) ENGINE=InnoDB
    `);

    // ── FOOD ITEMS ────────────────────────────────────────────────────────────
    await conn.query(`
      CREATE TABLE IF NOT EXISTS food_items (
        id            INT AUTO_INCREMENT PRIMARY KEY,
        uuid          VARCHAR(36) NOT NULL UNIQUE,
        donor_id      INT NOT NULL,
        title         VARCHAR(150) NOT NULL,
        category      ENUM('vegetables','fruits','grains','dairy','bakery','cooked_food','beverages','canned','other') NOT NULL,
        quantity       VARCHAR(50) NOT NULL,
        unit          VARCHAR(20) DEFAULT 'kg',
        description   TEXT,
        expiry_date   DATE NOT NULL,
        food_image    VARCHAR(255),
        pickup_address TEXT NOT NULL,
        latitude      DECIMAL(10,8),
        longitude     DECIMAL(11,8),
        status        ENUM('pending','available','claimed','collected','delivered','expired','unsafe','cancelled') DEFAULT 'pending',
        safety_status ENUM('unchecked','safe','unsafe') DEFAULT 'unchecked',
        is_perishable TINYINT(1) DEFAULT 1,
        serving_count INT DEFAULT 0,
        created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at    DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (donor_id) REFERENCES users(id) ON DELETE CASCADE
      ) ENGINE=InnoDB
    `);

    // ── REQUESTS ──────────────────────────────────────────────────────────────
    await conn.query(`
      CREATE TABLE IF NOT EXISTS requests (
        id              INT AUTO_INCREMENT PRIMARY KEY,
        uuid            VARCHAR(36) NOT NULL UNIQUE,
        food_item_id    INT NOT NULL,
        recipient_id    INT NOT NULL,
        volunteer_id    INT,
        request_type    ENUM('delivery','self_collection') DEFAULT 'delivery',
        pickup_address  TEXT,
        notes           TEXT,
        status          ENUM('pending','approved','assigned','collected','delivered','cancelled') DEFAULT 'pending',
        created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at      DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (food_item_id) REFERENCES food_items(id) ON DELETE CASCADE,
        FOREIGN KEY (recipient_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (volunteer_id) REFERENCES users(id) ON DELETE SET NULL
      ) ENGINE=InnoDB
    `);

    // ── DELIVERIES ────────────────────────────────────────────────────────────
    await conn.query(`
      CREATE TABLE IF NOT EXISTS deliveries (
        id              INT AUTO_INCREMENT PRIMARY KEY,
        uuid            VARCHAR(36) NOT NULL UNIQUE,
        request_id      INT NOT NULL UNIQUE,
        volunteer_id    INT NOT NULL,
        pickup_location TEXT,
        delivery_location TEXT,
        pickup_lat      DECIMAL(10,8),
        pickup_lng      DECIMAL(11,8),
        delivery_lat    DECIMAL(10,8),
        delivery_lng    DECIMAL(11,8),
        status          ENUM('assigned','on_the_way','collected','delivered','failed') DEFAULT 'assigned',
        picked_at       DATETIME,
        delivered_at    DATETIME,
        notes           TEXT,
        created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at      DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (request_id) REFERENCES requests(id) ON DELETE CASCADE,
        FOREIGN KEY (volunteer_id) REFERENCES users(id) ON DELETE CASCADE
      ) ENGINE=InnoDB
    `);

    // ── VERIFICATIONS ─────────────────────────────────────────────────────────
    await conn.query(`
      CREATE TABLE IF NOT EXISTS verifications (
        id                INT AUTO_INCREMENT PRIMARY KEY,
        food_item_id      INT NOT NULL,
        volunteer_id      INT NOT NULL,
        expiry_checked    TINYINT(1) DEFAULT 0,
        expiry_status     ENUM('valid','expired') DEFAULT 'valid',
        quality_checked   TINYINT(1) DEFAULT 0,
        packaging_ok      TINYINT(1) DEFAULT 0,
        smell_ok          TINYINT(1) DEFAULT 0,
        appearance_ok     TINYINT(1) DEFAULT 0,
        overall_status    ENUM('safe','unsafe') DEFAULT 'safe',
        notes             TEXT,
        verified_at       DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (food_item_id) REFERENCES food_items(id) ON DELETE CASCADE,
        FOREIGN KEY (volunteer_id) REFERENCES users(id) ON DELETE CASCADE
      ) ENGINE=InnoDB
    `);

    // ── NOTIFICATIONS ─────────────────────────────────────────────────────────
    await conn.query(`
      CREATE TABLE IF NOT EXISTS notifications (
        id          INT AUTO_INCREMENT PRIMARY KEY,
        user_id     INT NOT NULL,
        title       VARCHAR(200) NOT NULL,
        message     TEXT NOT NULL,
        type        ENUM('donation','request','delivery','system','alert','verification') DEFAULT 'system',
        related_id  INT,
        is_read     TINYINT(1) DEFAULT 0,
        created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      ) ENGINE=InnoDB
    `);

    // ── MESSAGES ──────────────────────────────────────────────────────────────
    await conn.query(`
      CREATE TABLE IF NOT EXISTS messages (
        id          INT AUTO_INCREMENT PRIMARY KEY,
        sender_id   INT NOT NULL,
        receiver_id INT NOT NULL,
        food_item_id INT,
        message     TEXT NOT NULL,
        is_read     TINYINT(1) DEFAULT 0,
        created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE
      ) ENGINE=InnoDB
    `);

    // ── FEEDBACK ──────────────────────────────────────────────────────────────
    await conn.query(`
      CREATE TABLE IF NOT EXISTS feedback (
        id          INT AUTO_INCREMENT PRIMARY KEY,
        from_user_id INT NOT NULL,
        to_user_id  INT,
        food_item_id INT,
        rating      TINYINT(1) NOT NULL CHECK (rating BETWEEN 1 AND 5),
        comment     TEXT,
        type        ENUM('donor','volunteer','platform') DEFAULT 'platform',
        created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (from_user_id) REFERENCES users(id) ON DELETE CASCADE
      ) ENGINE=InnoDB
    `);

    // ── CONTACTS (public contact form) ────────────────────────────────────────
    await conn.query(`
      CREATE TABLE IF NOT EXISTS contacts (
        id         INT AUTO_INCREMENT PRIMARY KEY,
        name       VARCHAR(100) NOT NULL,
        email      VARCHAR(150) NOT NULL,
        subject    VARCHAR(200),
        message    TEXT NOT NULL,
        is_read    TINYINT(1) DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB
    `);

    // ── SCHEDULES ─────────────────────────────────────────────────────────────
    await conn.query(`
      CREATE TABLE IF NOT EXISTS schedules (
        id            INT AUTO_INCREMENT PRIMARY KEY,
        volunteer_id  INT NOT NULL,
        food_item_id  INT NOT NULL,
        pickup_date   DATE NOT NULL,
        pickup_time   TIME NOT NULL,
        notes         TEXT,
        status        ENUM('scheduled','completed','cancelled') DEFAULT 'scheduled',
        created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (volunteer_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (food_item_id) REFERENCES food_items(id) ON DELETE CASCADE
      ) ENGINE=InnoDB
    `);

    console.log("✅ All tables created");

    // ── SEED ADMIN ────────────────────────────────────────────────────────────
    const { v4: uuidv4 } = require("uuid");
    const [existing] = await conn.query("SELECT id FROM users WHERE email = ?", [process.env.ADMIN_EMAIL]);
    if (existing.length === 0) {
      const hash = await bcrypt.hash(process.env.ADMIN_PASSWORD, 12);
      await conn.query(
        "INSERT INTO users (uuid, full_name, email, password, role, is_active, is_verified) VALUES (?, ?, ?, ?, 'admin', 1, 1)",
        [uuidv4(), process.env.ADMIN_NAME, process.env.ADMIN_EMAIL, hash]
      );
      console.log(`✅ Admin seeded: ${process.env.ADMIN_EMAIL} / ${process.env.ADMIN_PASSWORD}`);
    } else {
      console.log("✅ Admin already exists");
    }

    console.log("\n🎉 FoodLink database setup complete!\n");
  } catch (err) {
    console.error("❌ Setup error:", err.message);
    process.exit(1);
  } finally {
    if (conn) await conn.end();
  }
}

setup();
