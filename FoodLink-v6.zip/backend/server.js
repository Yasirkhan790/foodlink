require("dotenv").config();
const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const path = require("path");
const { errorHandler, notFound } = require("./middleware/errorHandler");

const app = express();
const PORT = process.env.PORT || 5000;

// ── Security ──────────────────────────────────────────────────────────────────
app.use(helmet({ crossOriginResourcePolicy: { policy: "cross-origin" } }));

app.use(cors({
  origin: [
    process.env.FRONTEND_URL || "http://127.0.0.1:5500",
    "http://localhost:5500",
    "http://127.0.0.1:3000",
    "http://localhost:3000",
    "null",
  ],
  credentials: true,
  methods: ["GET","POST","PUT","DELETE","OPTIONS"],
  allowedHeaders: ["Content-Type","Authorization"],
}));

app.use(rateLimit({ windowMs: 15*60*1000, max: 300,
  message: { success: false, message: "Too many requests." } }));

// ── Body Parsers ──────────────────────────────────────────────────────────────
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true, limit: "10mb" }));

// ── Static Files ──────────────────────────────────────────────────────────────
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// ── API Routes ────────────────────────────────────────────────────────────────
app.use("/api/auth",     require("./routes/auth"));
app.use("/api/food",     require("./routes/food"));
app.use("/api/requests", require("./routes/requests"));
app.use("/api",          require("./routes/admin"));

// ── Health Check ─────────────────────────────────────────────────────────────
app.get("/api/health", (req, res) => res.json({
  success: true, message: "FoodLink API running 🍱", version: "1.0.0",
  timestamp: new Date().toISOString(),
}));

// ── Error Handlers ────────────────────────────────────────────────────────────
app.use(notFound);
app.use(errorHandler);

app.listen(PORT, () => {
  console.log("\n🍱 ===================================");
  console.log(`   FoodLink API → http://localhost:${PORT}`);
  console.log(`   Health      → http://localhost:${PORT}/api/health`);
  console.log("=====================================\n");
});

module.exports = app;
