const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { v4: uuidv4 } = require("uuid");
const { validationResult } = require("express-validator");
const db = require("../config/db");

const signToken = (user) =>
  jwt.sign({ id: user.id, email: user.email, role: user.role }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || "7d",
  });

// POST /api/auth/register
const register = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty())
      return res.status(400).json({ success: false, message: errors.array()[0].msg });

    const { full_name, email, phone, password, role, donor_type, address, city } = req.body;

    const [exists] = await db.execute("SELECT id FROM users WHERE email = ?", [email.toLowerCase()]);
    if (exists.length)
      return res.status(400).json({ success: false, message: "Email already registered." });

    const hash = await bcrypt.hash(password, 12);
    const id = uuidv4();

    await db.execute(
      `INSERT INTO users (uuid, full_name, email, phone, password, role, donor_type, address, city)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [id, full_name, email.toLowerCase(), phone || null, hash,
       role || "donor", donor_type || null, address || null, city || null]
    );

    const [newUser] = await db.execute("SELECT id FROM users WHERE uuid = ?", [id]);
    const userId = newUser[0].id;

    // Welcome notification
    await db.execute(
      "INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, 'system')",
      [userId, "Welcome to FoodLink! 🎉",
       `Hi ${full_name}, your account has been created. Start making a difference today!`]
    );

    res.status(201).json({ success: true, message: "Registration successful! Please log in." });
  } catch (err) {
    console.error("Register error:", err);
    res.status(500).json({ success: false, message: "Registration failed. Try again." });
  }
};

// POST /api/auth/login
const login = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty())
      return res.status(400).json({ success: false, message: errors.array()[0].msg });

    const { email, password, role } = req.body;

    const [rows] = await db.execute(
      "SELECT * FROM users WHERE email = ? AND is_active = 1",
      [email.toLowerCase()]
    );
    if (!rows.length)
      return res.status(401).json({ success: false, message: "Invalid email or password." });

    const user = rows[0];

    if (role && user.role !== role)
      return res.status(401).json({
        success: false,
        message: `This account is registered as ${user.role}, not ${role}.`,
      });

    const match = await bcrypt.compare(password, user.password);
    if (!match)
      return res.status(401).json({ success: false, message: "Invalid email or password." });

    await db.execute("UPDATE users SET last_login = NOW() WHERE id = ?", [user.id]);

    const token = signToken(user);

    res.json({
      success: true,
      message: "Login successful",
      token,
      user: {
        id: user.id,
        uuid: user.uuid,
        name: user.full_name,
        email: user.email,
        phone: user.phone,
        role: user.role,
        address: user.address,
        city: user.city,
        profile_image: user.profile_image,
        donor_type: user.donor_type,
      },
    });
  } catch (err) {
    console.error("Login error:", err);
    res.status(500).json({ success: false, message: "Login failed." });
  }
};

// GET /api/auth/me
const getMe = async (req, res) => {
  try {
    const [rows] = await db.execute(
      `SELECT id, uuid, full_name, email, phone, role, donor_type, address, city,
              profile_image, is_verified, created_at, last_login
       FROM users WHERE id = ?`,
      [req.user.id]
    );
    if (!rows.length)
      return res.status(404).json({ success: false, message: "User not found." });
    res.json({ success: true, user: rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed to fetch profile." });
  }
};

// PUT /api/auth/update-profile
const updateProfile = async (req, res) => {
  try {
    const { full_name, phone, address, city, donor_type } = req.body;
    let profile_image = null;
    if (req.file) profile_image = `/uploads/${req.file.filename}`;

    const fields = [];
    const vals = [];
    if (full_name) { fields.push("full_name = ?"); vals.push(full_name); }
    if (phone)     { fields.push("phone = ?");     vals.push(phone); }
    if (address)   { fields.push("address = ?");   vals.push(address); }
    if (city)      { fields.push("city = ?");      vals.push(city); }
    if (donor_type){ fields.push("donor_type = ?");vals.push(donor_type); }
    if (profile_image){ fields.push("profile_image = ?"); vals.push(profile_image); }

    if (!fields.length)
      return res.status(400).json({ success: false, message: "No fields to update." });

    vals.push(req.user.id);
    await db.execute(`UPDATE users SET ${fields.join(", ")} WHERE id = ?`, vals);

    const [updated] = await db.execute(
      "SELECT id, uuid, full_name, email, phone, role, address, city, profile_image FROM users WHERE id = ?",
      [req.user.id]
    );
    res.json({ success: true, message: "Profile updated.", user: updated[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: "Profile update failed." });
  }
};

// PUT /api/auth/change-password
const changePassword = async (req, res) => {
  try {
    const { current_password, new_password } = req.body;
    const [rows] = await db.execute("SELECT password FROM users WHERE id = ?", [req.user.id]);
    const match = await bcrypt.compare(current_password, rows[0].password);
    if (!match)
      return res.status(400).json({ success: false, message: "Current password is incorrect." });
    const hash = await bcrypt.hash(new_password, 12);
    await db.execute("UPDATE users SET password = ? WHERE id = ?", [hash, req.user.id]);
    res.json({ success: true, message: "Password changed successfully." });
  } catch (err) {
    res.status(500).json({ success: false, message: "Password change failed." });
  }
};

module.exports = { register, login, getMe, updateProfile, changePassword };
