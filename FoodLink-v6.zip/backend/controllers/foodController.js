const { v4: uuidv4 } = require("uuid");
const db = require("../config/db");

// POST /api/food — donor posts a donation
const create = async (req, res) => {
  try {
    const { title, category, quantity, unit, description, expiry_date,
            pickup_address, latitude, longitude, is_perishable, serving_count } = req.body;

    if (!title || !category || !quantity || !expiry_date || !pickup_address)
      return res.status(400).json({ success: false, message: "All required fields must be filled." });

    const today = new Date().toISOString().split("T")[0];
    if (expiry_date < today)
      return res.status(400).json({ success: false, message: "Expiry date cannot be in the past." });

    const food_image = req.file ? `/uploads/${req.file.filename}` : null;
    const id = uuidv4();

    await db.execute(
      `INSERT INTO food_items (uuid, donor_id, title, category, quantity, unit, description,
        expiry_date, food_image, pickup_address, latitude, longitude, status, is_perishable, serving_count)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'available', ?, ?)`,
      [id, req.user.id, title, category, quantity, unit || "kg", description || null,
       expiry_date, food_image, pickup_address, latitude || null, longitude || null,
       is_perishable ? 1 : 0, serving_count || 0]
    );

    const [item] = await db.execute("SELECT * FROM food_items WHERE uuid = ?", [id]);

    // Notify all volunteers
    const [volunteers] = await db.execute(
      "SELECT id FROM users WHERE role = 'volunteer' AND is_active = 1"
    );
    if (volunteers.length) {
      const notifSQL = "INSERT INTO notifications (user_id, title, message, type, related_id) VALUES ?";
      const vals = volunteers.map(v => [
        v.id, "New Food Available! 🍱",
        `${req.user.full_name} posted ${title} (${quantity} ${unit || "kg"}) — ${pickup_address}`,
        "donation", item[0].id
      ]);
      await db.query(notifSQL, [vals]);
    }

    res.status(201).json({ success: true, message: "Food posted successfully!", food_item: item[0] });
  } catch (err) {
    console.error("Create food error:", err);
    res.status(500).json({ success: false, message: "Failed to post food." });
  }
};

// GET /api/food — get all available food (public + authenticated)
const getAll = async (req, res) => {
  try {
    const { category, status = "available", search, page = 1, limit = 12 } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);

    let query = `
      SELECT f.*, u.full_name AS donor_name, u.phone AS donor_phone,
             u.city AS donor_city, u.profile_image AS donor_image
      FROM food_items f JOIN users u ON f.donor_id = u.id
      WHERE f.status = ? AND f.expiry_date >= CURDATE()
    `;
    const params = [status];

    if (category && category !== "all") { query += " AND f.category = ?"; params.push(category); }
    if (search) { query += " AND (f.title LIKE ? OR f.description LIKE ?)"; params.push(`%${search}%`, `%${search}%`); }
    query += " ORDER BY f.created_at DESC LIMIT ? OFFSET ?";
    params.push(parseInt(limit), offset);

    const [items] = await db.execute(query, params);

    let cq = `SELECT COUNT(*) as t FROM food_items f WHERE f.status = ? AND f.expiry_date >= CURDATE()`;
    const cp = [status];
    if (category && category !== "all") { cq += " AND f.category = ?"; cp.push(category); }
    const [[{ t }]] = await db.execute(cq, cp);

    res.json({
      success: true,
      food_items: items,
      pagination: { total: t, page: +page, limit: +limit, pages: Math.ceil(t / +limit) },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Failed to fetch food." });
  }
};

// GET /api/food/my — donor's own donations
const getMine = async (req, res) => {
  try {
    const [items] = await db.execute(
      `SELECT f.*, 
        (SELECT COUNT(*) FROM requests r WHERE r.food_item_id = f.id) AS request_count
       FROM food_items f WHERE f.donor_id = ? ORDER BY f.created_at DESC`,
      [req.user.id]
    );
    res.json({ success: true, food_items: items });
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed to fetch your donations." });
  }
};

// GET /api/food/stats — donor stats
const getStats = async (req, res) => {
  try {
    const uid = req.user.id;
    const role = req.user.role;
    let stats = {};

    if (role === "donor") {
      const [[s]] = await db.execute(
        `SELECT COUNT(*) as total,
          SUM(status='available') as active,
          SUM(status='delivered') as delivered,
          SUM(status='claimed') as claimed,
          SUM(status='collected') as collected
         FROM food_items WHERE donor_id = ?`, [uid]
      );
      stats = s;
    } else if (role === "volunteer") {
      const [[s]] = await db.execute(
        `SELECT COUNT(*) as total_assigned,
          SUM(d.status='delivered') as completed,
          SUM(d.status='on_the_way') as in_progress
         FROM deliveries d WHERE d.volunteer_id = ?`, [uid]
      );
      stats = s;
    } else if (role === "recipient") {
      const [[s]] = await db.execute(
        `SELECT COUNT(*) as total_requested,
          SUM(status='delivered') as received,
          SUM(status='pending') as pending
         FROM requests WHERE recipient_id = ?`, [uid]
      );
      stats = s;
    }

    res.json({ success: true, stats });
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed to get stats." });
  }
};

// GET /api/food/:id — single food item
const getOne = async (req, res) => {
  try {
    const [rows] = await db.execute(
      `SELECT f.*, u.full_name AS donor_name, u.phone AS donor_phone,
              u.email AS donor_email, u.address AS donor_address
       FROM food_items f JOIN users u ON f.donor_id = u.id
       WHERE f.id = ? OR f.uuid = ?`,
      [req.params.id, req.params.id]
    );
    if (!rows.length) return res.status(404).json({ success: false, message: "Not found." });
    res.json({ success: true, food_item: rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed." });
  }
};

// PUT /api/food/:id — donor updates
const update = async (req, res) => {
  try {
    const [rows] = await db.execute(
      "SELECT * FROM food_items WHERE id = ? AND donor_id = ?",
      [req.params.id, req.user.id]
    );
    if (!rows.length) return res.status(404).json({ success: false, message: "Not found." });

    const { title, category, quantity, unit, description, expiry_date,
            pickup_address, status, serving_count } = req.body;
    const food_image = req.file ? `/uploads/${req.file.filename}` : null;

    const fields = [];
    const vals = [];
    if (title)          { fields.push("title = ?");          vals.push(title); }
    if (category)       { fields.push("category = ?");       vals.push(category); }
    if (quantity)       { fields.push("quantity = ?");       vals.push(quantity); }
    if (unit)           { fields.push("unit = ?");           vals.push(unit); }
    if (description !== undefined) { fields.push("description = ?"); vals.push(description); }
    if (expiry_date)    { fields.push("expiry_date = ?");    vals.push(expiry_date); }
    if (pickup_address) { fields.push("pickup_address = ?"); vals.push(pickup_address); }
    if (status)         { fields.push("status = ?");         vals.push(status); }
    if (serving_count)  { fields.push("serving_count = ?");  vals.push(serving_count); }
    if (food_image)     { fields.push("food_image = ?");     vals.push(food_image); }

    if (!fields.length) return res.status(400).json({ success: false, message: "Nothing to update." });

    vals.push(req.params.id);
    await db.execute(`UPDATE food_items SET ${fields.join(", ")} WHERE id = ?`, vals);

    const [updated] = await db.execute("SELECT * FROM food_items WHERE id = ?", [req.params.id]);
    res.json({ success: true, message: "Updated.", food_item: updated[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: "Update failed." });
  }
};

// DELETE /api/food/:id
const remove = async (req, res) => {
  try {
    const [rows] = await db.execute(
      "SELECT id FROM food_items WHERE id = ? AND donor_id = ?",
      [req.params.id, req.user.id]
    );
    if (!rows.length) return res.status(404).json({ success: false, message: "Not found." });
    await db.execute("DELETE FROM food_items WHERE id = ?", [req.params.id]);
    res.json({ success: true, message: "Deleted." });
  } catch (err) {
    res.status(500).json({ success: false, message: "Delete failed." });
  }
};

module.exports = { create, getAll, getMine, getStats, getOne, update, remove };
