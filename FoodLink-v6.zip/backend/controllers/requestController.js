const { v4: uuidv4 } = require("uuid");
const db = require("../config/db");

// POST /api/requests
const createRequest = async (req, res) => {
  try {
    const { food_item_id, request_type, pickup_address, notes } = req.body;
    if (!food_item_id)
      return res.status(400).json({ success: false, message: "food_item_id required." });

    const [food] = await db.execute(
      "SELECT * FROM food_items WHERE id = ? AND status = 'available' AND expiry_date >= CURDATE()",
      [food_item_id]
    );
    if (!food.length)
      return res.status(400).json({ success: false, message: "Food item not available." });

    const [dup] = await db.execute(
      "SELECT id FROM requests WHERE food_item_id = ? AND recipient_id = ? AND status NOT IN ('cancelled')",
      [food_item_id, req.user.id]
    );
    if (dup.length)
      return res.status(400).json({ success: false, message: "You already requested this item." });

    const rtype = request_type || "delivery";
    const initialStatus = rtype === "self_collection" ? "approved" : "pending";
    const id = uuidv4();

    await db.execute(
      `INSERT INTO requests (uuid, food_item_id, recipient_id, request_type, pickup_address, notes, status)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [id, food_item_id, req.user.id, rtype, pickup_address || null, notes || null, initialStatus]
    );

    if (rtype === "delivery") {
      await db.execute("UPDATE food_items SET status = 'claimed' WHERE id = ?", [food_item_id]);
    }

    const [req_row] = await db.execute("SELECT id FROM requests WHERE uuid = ?", [id]);
    const requestId = req_row[0].id;

    const [[recipient]] = await db.execute("SELECT full_name FROM users WHERE id = ?", [req.user.id]);

    if (rtype === "self_collection") {
      // Auto-open chat with donor
      const autoMsg = `👋 Hi! I'd like to self-collect your food donation "${food[0].title}". Can we arrange a pickup time? I will come to: ${food[0].pickup_address}`;
      await db.execute(
        "INSERT INTO messages (sender_id, receiver_id, message, food_item_id) VALUES (?, ?, ?, ?)",
        [req.user.id, food[0].donor_id, autoMsg, food_item_id]
      );
      await db.execute(
        "INSERT INTO notifications (user_id, title, message, type, related_id) VALUES (?, ?, ?, 'request', ?)",
        [food[0].donor_id, "🤝 Self-Collection Request!", `${recipient.full_name} wants to self-collect your "${food[0].title}". Check Messages to arrange pickup.`, requestId]
      );
      return res.status(201).json({
        success: true,
        message: "Self-collection request sent! Chat with the donor to arrange pickup.",
        request_id: requestId,
        request_type: "self_collection",
        donor_id: food[0].donor_id,
        open_chat: true
      });
    } else {
      // Delivery: notify donor + auto message in inbox
      const deliveryMsg = `📦 Hi, I've requested home delivery for your "${food[0].title}". A volunteer will be assigned to pick it up from you soon.`;
      await db.execute(
        "INSERT INTO messages (sender_id, receiver_id, message, food_item_id) VALUES (?, ?, ?, ?)",
        [req.user.id, food[0].donor_id, deliveryMsg, food_item_id]
      );
      await db.execute(
        "INSERT INTO notifications (user_id, title, message, type, related_id) VALUES (?, ?, ?, 'request', ?)",
        [food[0].donor_id, "Your Food was Requested! 🙏", `${recipient.full_name} requested delivery for: "${food[0].title}"`, requestId]
      );
      const [vols] = await db.execute("SELECT id FROM users WHERE role = 'volunteer' AND is_active = 1");
      if (vols.length) {
        const notifVals = vols.map(v => [v.id, "New Delivery Task 🚗", `${recipient.full_name} needs delivery for: "${food[0].title}"`, "request", requestId]);
        await db.query("INSERT INTO notifications (user_id, title, message, type, related_id) VALUES ?", [notifVals]);
      }
      return res.status(201).json({
        success: true,
        message: "Delivery request submitted! Volunteers will be notified.",
        request_id: requestId,
        request_type: "delivery",
        donor_id: food[0].donor_id,
        open_chat: false
      });
    }
  } catch (err) {
    console.error("createRequest error:", err);
    res.status(500).json({ success: false, message: "Request failed." });
  }
};

// GET /api/requests/mine
const getMyRequests = async (req, res) => {
  try {
    const [rows] = await db.execute(
      `SELECT r.*,
              f.title, f.category, f.quantity, f.unit, f.food_image,
              f.pickup_address, f.expiry_date, f.status AS food_status,
              f.donor_id,
              u.full_name AS donor_name, u.phone AS donor_phone, u.id AS donor_user_id,
              v.full_name AS volunteer_name, v.phone AS volunteer_phone
       FROM requests r
       JOIN food_items f ON r.food_item_id = f.id
       JOIN users u ON f.donor_id = u.id
       LEFT JOIN users v ON r.volunteer_id = v.id
       WHERE r.recipient_id = ? ORDER BY r.created_at DESC`,
      [req.user.id]
    );
    res.json({ success: true, requests: rows });
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed." });
  }
};

// GET /api/requests/available
const getAvailableRequests = async (req, res) => {
  try {
    const [rows] = await db.execute(
      `SELECT r.*, f.title, f.category, f.quantity, f.unit, f.food_image,
              f.pickup_address, f.expiry_date,
              f.donor_id, u.id AS donor_user_id,
              u.full_name AS donor_name, u.phone AS donor_phone,
              rc.full_name AS recipient_name, rc.phone AS recipient_phone,
              rc.address AS recipient_address
       FROM requests r
       JOIN food_items f ON r.food_item_id = f.id
       JOIN users u ON f.donor_id = u.id
       JOIN users rc ON r.recipient_id = rc.id
       WHERE r.status = 'approved' AND r.volunteer_id IS NULL AND r.request_type = 'delivery'
       ORDER BY r.created_at DESC`
    );
    res.json({ success: true, requests: rows });
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed." });
  }
};

// GET /api/requests/my-tasks
const getMyTasks = async (req, res) => {
  try {
    const [rows] = await db.execute(
      `SELECT r.*, f.title, f.category, f.quantity, f.unit, f.food_image,
              f.pickup_address, f.expiry_date, f.latitude, f.longitude,
              f.donor_id, u.id AS donor_user_id,
              u.full_name AS donor_name, u.phone AS donor_phone,
              rc.full_name AS recipient_name, rc.phone AS recipient_phone,
              rc.address AS recipient_address,
              d.status AS delivery_status, d.id AS delivery_id
       FROM requests r
       JOIN food_items f ON r.food_item_id = f.id
       JOIN users u ON f.donor_id = u.id
       JOIN users rc ON r.recipient_id = rc.id
       LEFT JOIN deliveries d ON d.request_id = r.id
       WHERE r.volunteer_id = ?
       ORDER BY r.created_at DESC`,
      [req.user.id]
    );
    res.json({ success: true, requests: rows });
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed." });
  }
};

// PUT /api/requests/:id/accept
const acceptTask = async (req, res) => {
  try {
    const [rows] = await db.execute(
      "SELECT * FROM requests WHERE id = ? AND status = 'approved' AND volunteer_id IS NULL",
      [req.params.id]
    );
    if (!rows.length)
      return res.status(400).json({ success: false, message: "Task not available." });

    await db.execute("UPDATE requests SET volunteer_id = ?, status = 'assigned' WHERE id = ?",
      [req.user.id, req.params.id]);

    const [food] = await db.execute("SELECT * FROM food_items WHERE id = ?", [rows[0].food_item_id]);
    const delId = uuidv4();
    await db.execute(
      `INSERT INTO deliveries (uuid, request_id, volunteer_id, pickup_location, delivery_location) VALUES (?, ?, ?, ?, ?)`,
      [delId, req.params.id, req.user.id, food[0].pickup_address, rows[0].pickup_address || "Recipient address"]
    );

    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    await db.execute(
      "INSERT INTO schedules (volunteer_id, food_item_id, pickup_date, pickup_time) VALUES (?, ?, ?, '10:00:00')",
      [req.user.id, rows[0].food_item_id, tomorrow.toISOString().split("T")[0]]
    );

    await db.execute(
      "INSERT INTO notifications (user_id, title, message, type, related_id) VALUES (?, ?, ?, 'delivery', ?)",
      [rows[0].recipient_id, "Volunteer Assigned! 🚗", "A volunteer has been assigned and will deliver your food soon.", req.params.id]
    );

    // Auto-send chat message to donor so task shows "in_progress" when chatting starts
    const [[vol]] = await db.execute("SELECT full_name FROM users WHERE id = ?", [req.user.id]);
    const autoMsg = `👋 Hi! I'm ${vol.full_name}, your assigned volunteer. I'll be picking up your food donation shortly.`;
    await db.execute(
      "INSERT INTO messages (sender_id, receiver_id, message, food_item_id) VALUES (?, ?, ?, ?)",
      [req.user.id, food[0].donor_id, autoMsg, rows[0].food_item_id]
    );

    res.json({ success: true, message: "Task accepted! Delivery created.", donor_id: food[0].donor_id });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Accept failed." });
  }
};

// PUT /api/requests/:id/status
const updateStatus = async (req, res) => {
  try {
    const { status, notes } = req.body;
    const allowed = ["approved", "assigned", "in_progress", "collected", "delivered", "completed", "cancelled"];
    if (!allowed.includes(status))
      return res.status(400).json({ success: false, message: "Invalid status." });

    const [rows] = await db.execute("SELECT * FROM requests WHERE id = ?", [req.params.id]);
    if (!rows.length) return res.status(404).json({ success: false, message: "Not found." });

    await db.execute("UPDATE requests SET status = ? WHERE id = ?", [status, req.params.id]);

    const foodStatusMap = { collected: "collected", delivered: "delivered", completed: "delivered", cancelled: "available" };
    if (foodStatusMap[status]) {
      await db.execute("UPDATE food_items SET status = ? WHERE id = ?", [foodStatusMap[status], rows[0].food_item_id]);
    }

    if (status === "collected" || status === "delivered") {
      const deliveryField = status === "collected" ? "picked_at" : "delivered_at";
      await db.execute(
        `UPDATE deliveries SET status = ?, ${deliveryField} = NOW(), notes = ? WHERE request_id = ?`,
        [status === "collected" ? "collected" : "delivered", notes || null, req.params.id]
      );
    }

    const notifTitle = status === "delivered" || status === "completed" ? "Food Delivered! ✅" : `Request status: ${status}`;
    await db.execute(
      "INSERT INTO notifications (user_id, title, message, type, related_id) VALUES (?, ?, ?, 'delivery', ?)",
      [rows[0].recipient_id, notifTitle, `Your food request status updated to: ${status}`, req.params.id]
    );

    res.json({ success: true, message: `Status updated to ${status}` });
  } catch (err) {
    res.status(500).json({ success: false, message: "Status update failed." });
  }
};

// POST /api/requests/verifications
const submitVerification = async (req, res) => {
  try {
    const { food_item_id, expiry_checked, expiry_status, quality_checked,
            packaging_ok, smell_ok, appearance_ok, overall_status, notes } = req.body;
    if (!food_item_id)
      return res.status(400).json({ success: false, message: "food_item_id required." });
    await db.execute(
      `INSERT INTO verifications (food_item_id, volunteer_id, expiry_checked, expiry_status,
        quality_checked, packaging_ok, smell_ok, appearance_ok, overall_status, notes)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [food_item_id, req.user.id, expiry_checked ? 1 : 0, expiry_status || "valid",
       quality_checked ? 1 : 0, packaging_ok ? 1 : 0, smell_ok ? 1 : 0,
       appearance_ok ? 1 : 0, overall_status || "safe", notes || null]
    );
    await db.execute("UPDATE food_items SET safety_status = ? WHERE id = ?", [overall_status || "safe", food_item_id]);
    if (overall_status === "unsafe") {
      await db.execute("UPDATE food_items SET status = 'unsafe' WHERE id = ?", [food_item_id]);
      const [[food]] = await db.execute("SELECT donor_id, title FROM food_items WHERE id = ?", [food_item_id]);
      await db.execute(
        "INSERT INTO notifications (user_id, title, message, type, related_id) VALUES (?, ?, ?, 'alert', ?)",
        [food.donor_id, "⚠️ Food Safety Alert", `Your donation "${food.title}" did not pass safety verification.`, food_item_id]
      );
    }
    res.status(201).json({ success: true, message: "Verification submitted." });
  } catch (err) {
    res.status(500).json({ success: false, message: "Verification failed." });
  }
};

const getFoodVerification = async (req, res) => {
  try {
    const [rows] = await db.execute(
      `SELECT v.*, u.full_name AS volunteer_name FROM verifications v
       JOIN users u ON v.volunteer_id = u.id WHERE v.food_item_id = ?
       ORDER BY v.verified_at DESC LIMIT 1`,
      [req.params.id]
    );
    res.json({ success: true, verification: rows[0] || null });
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed." });
  }
};

const getMyDeliveries = async (req, res) => {
  try {
    const [rows] = await db.execute(
      `SELECT d.*, r.request_type,
              f.title, f.category, f.quantity, f.unit, f.food_image,
              donor.full_name AS donor_name, donor.phone AS donor_phone,
              recip.full_name AS recipient_name, recip.phone AS recipient_phone,
              recip.address AS recipient_address
       FROM deliveries d
       JOIN requests r ON d.request_id = r.id
       JOIN food_items f ON r.food_item_id = f.id
       JOIN users donor ON f.donor_id = donor.id
       JOIN users recip ON r.recipient_id = recip.id
       WHERE d.volunteer_id = ? ORDER BY d.created_at DESC`,
      [req.user.id]
    );
    res.json({ success: true, deliveries: rows });
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed." });
  }
};

const getMySchedule = async (req, res) => {
  try {
    const [rows] = await db.execute(
      `SELECT s.*, f.title, f.pickup_address, f.category,
              u.full_name AS donor_name, u.phone AS donor_phone
       FROM schedules s JOIN food_items f ON s.food_item_id = f.id
       JOIN users u ON f.donor_id = u.id
       WHERE s.volunteer_id = ? ORDER BY s.pickup_date ASC, s.pickup_time ASC`,
      [req.user.id]
    );
    res.json({ success: true, schedules: rows });
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed." });
  }
};

module.exports = {
  createRequest, getMyRequests, getAvailableRequests, getMyTasks,
  acceptTask, updateStatus, submitVerification, getFoodVerification,
  getMyDeliveries, getMySchedule,
};
