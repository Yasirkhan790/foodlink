const db = require("../config/db");

// ── ADMIN ─────────────────────────────────────────────────────────────────────

const getDashboardStats = async (req, res) => {
  try {
    const [[users]]  = await db.execute("SELECT COUNT(*) t FROM users WHERE role != 'admin'");
    const [[donors]] = await db.execute("SELECT COUNT(*) t FROM users WHERE role='donor'");
    const [[vols]]   = await db.execute("SELECT COUNT(*) t FROM users WHERE role='volunteer'");
    const [[recips]] = await db.execute("SELECT COUNT(*) t FROM users WHERE role='recipient'");
    const [[food]]   = await db.execute("SELECT COUNT(*) t FROM food_items");
    const [[avail]]  = await db.execute("SELECT COUNT(*) t FROM food_items WHERE status='available'");
    const [[del]]    = await db.execute("SELECT COUNT(*) t FROM food_items WHERE status='delivered'");
    const [[reqs]]   = await db.execute("SELECT COUNT(*) t FROM requests");

    const [recentFood] = await db.execute(
      `SELECT f.*, u.full_name AS donor_name FROM food_items f
       JOIN users u ON f.donor_id = u.id ORDER BY f.created_at DESC LIMIT 10`
    );
    const [recentUsers] = await db.execute(
      "SELECT id, full_name, email, role, created_at, is_active FROM users WHERE role != 'admin' ORDER BY created_at DESC LIMIT 10"
    );
    const [monthly] = await db.execute(`
      SELECT DATE_FORMAT(created_at, '%b %Y') AS month, COUNT(*) AS count
      FROM food_items WHERE created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
      GROUP BY DATE_FORMAT(created_at, '%b %Y') ORDER BY created_at ASC
    `);

    res.json({
      success: true,
      stats: {
        total_users: users.t, donors: donors.t, volunteers: vols.t, recipients: recips.t,
        total_food: food.t, available: avail.t, delivered: del.t, total_requests: reqs.t,
      },
      recent_food: recentFood,
      recent_users: recentUsers,
      monthly_data: monthly,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Failed to fetch stats." });
  }
};

const getAllUsers = async (req, res) => {
  try {
    const { role, search, page = 1, limit = 20 } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);
    let q = "SELECT id, uuid, full_name, email, phone, role, address, city, is_active, created_at, last_login FROM users WHERE role != 'admin'";
    const p = [];
    if (role)   { q += " AND role = ?"; p.push(role); }
    if (search) { q += " AND (full_name LIKE ? OR email LIKE ?)"; p.push(`%${search}%`, `%${search}%`); }
    q += " ORDER BY created_at DESC LIMIT ? OFFSET ?";
    p.push(parseInt(limit), offset);
    const [users] = await db.execute(q, p);

    let cq = "SELECT COUNT(*) t FROM users WHERE role != 'admin'";
    const cp = [];
    if (role) { cq += " AND role = ?"; cp.push(role); }
    const [[{ t }]] = await db.execute(cq, cp);

    res.json({ success: true, users, total: t });
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed." });
  }
};

const toggleUserStatus = async (req, res) => {
  try {
    const [[user]] = await db.execute("SELECT is_active FROM users WHERE id = ? AND role != 'admin'", [req.params.id]);
    if (!user) return res.status(404).json({ success: false, message: "User not found." });
    const newStatus = user.is_active ? 0 : 1;
    await db.execute("UPDATE users SET is_active = ? WHERE id = ?", [newStatus, req.params.id]);
    res.json({ success: true, message: `User ${newStatus ? "activated" : "deactivated"}.`, is_active: newStatus });
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed." });
  }
};

const deleteUser = async (req, res) => {
  try {
    await db.execute("DELETE FROM users WHERE id = ? AND role != 'admin'", [req.params.id]);
    res.json({ success: true, message: "User deleted." });
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed." });
  }
};

const getAllFood = async (req, res) => {
  try {
    const { status, page = 1, limit = 20 } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);
    let q = `SELECT f.*, u.full_name AS donor_name, u.email AS donor_email
             FROM food_items f JOIN users u ON f.donor_id = u.id`;
    const p = [];
    if (status) { q += " WHERE f.status = ?"; p.push(status); }
    q += " ORDER BY f.created_at DESC LIMIT ? OFFSET ?";
    p.push(parseInt(limit), offset);
    const [food] = await db.execute(q, p);
    res.json({ success: true, food_items: food });
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed." });
  }
};

const getReports = async (req, res) => {
  try {
    const [byCategory] = await db.execute(
      "SELECT category, COUNT(*) count FROM food_items GROUP BY category ORDER BY count DESC"
    );
    const [byStatus] = await db.execute(
      "SELECT status, COUNT(*) count FROM food_items GROUP BY status"
    );
    const [byRole] = await db.execute(
      "SELECT role, COUNT(*) count FROM users GROUP BY role"
    );
    const [weeklyActivity] = await db.execute(`
      SELECT DATE(created_at) date, COUNT(*) food_items
      FROM food_items WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
      GROUP BY DATE(created_at) ORDER BY date ASC
    `);
    const [safetyStats] = await db.execute(
      "SELECT safety_status, COUNT(*) count FROM food_items GROUP BY safety_status"
    );
    res.json({ success: true, reports: { byCategory, byStatus, byRole, weeklyActivity, safetyStats } });
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed." });
  }
};

const getContactMessages = async (req, res) => {
  try {
    const [messages] = await db.execute("SELECT * FROM contacts ORDER BY created_at DESC");
    res.json({ success: true, messages });
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed." });
  }
};

// ── NOTIFICATIONS ─────────────────────────────────────────────────────────────

const getNotifications = async (req, res) => {
  try {
    const [notifs] = await db.execute(
      "SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 50",
      [req.user.id]
    );
    const [[{ unread }]] = await db.execute(
      "SELECT COUNT(*) unread FROM notifications WHERE user_id = ? AND is_read = 0",
      [req.user.id]
    );
    res.json({ success: true, notifications: notifs, unread_count: unread });
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed." });
  }
};

const markRead = async (req, res) => {
  try {
    await db.execute("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?",
      [req.params.id, req.user.id]);
    res.json({ success: true, message: "Marked as read." });
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed." });
  }
};

const markAllRead = async (req, res) => {
  try {
    await db.execute("UPDATE notifications SET is_read = 1 WHERE user_id = ?", [req.user.id]);
    res.json({ success: true, message: "All marked as read." });
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed." });
  }
};

// ── MESSAGES ──────────────────────────────────────────────────────────────────

const getConversations = async (req, res) => {
  try {
    const [convs] = await db.execute(`
      SELECT DISTINCT
        CASE WHEN m.sender_id = ? THEN m.receiver_id ELSE m.sender_id END AS other_id,
        u.full_name, u.role, u.profile_image,
        m.message AS last_message, m.created_at,
        SUM(CASE WHEN m.receiver_id = ? AND m.is_read = 0 THEN 1 ELSE 0 END) AS unread
      FROM messages m
      JOIN users u ON u.id = (CASE WHEN m.sender_id = ? THEN m.receiver_id ELSE m.sender_id END)
      WHERE m.sender_id = ? OR m.receiver_id = ?
      GROUP BY other_id ORDER BY m.created_at DESC
    `, [req.user.id, req.user.id, req.user.id, req.user.id, req.user.id]);
    res.json({ success: true, conversations: convs });
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed." });
  }
};

const getMessages = async (req, res) => {
  try {
    const other = req.params.userId;
    const [msgs] = await db.execute(
      `SELECT m.*, u.full_name AS sender_name
       FROM messages m JOIN users u ON m.sender_id = u.id
       WHERE (m.sender_id = ? AND m.receiver_id = ?) OR (m.sender_id = ? AND m.receiver_id = ?)
       ORDER BY m.created_at ASC LIMIT 100`,
      [req.user.id, other, other, req.user.id]
    );
    await db.execute("UPDATE messages SET is_read = 1 WHERE sender_id = ? AND receiver_id = ?",
      [other, req.user.id]);
    res.json({ success: true, messages: msgs });
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed." });
  }
};

const sendMessage = async (req, res) => {
  try {
    const { receiver_id, message, food_item_id } = req.body;
    if (!receiver_id || !message)
      return res.status(400).json({ success: false, message: "receiver_id and message required." });
    await db.execute(
      "INSERT INTO messages (sender_id, receiver_id, message, food_item_id) VALUES (?, ?, ?, ?)",
      [req.user.id, receiver_id, message, food_item_id || null]
    );
    // Notify receiver
    await db.execute(
      "INSERT INTO notifications (user_id, title, message, type, related_id) VALUES (?, ?, ?, 'system', ?)",
      [receiver_id, `💬 New message from ${req.user.full_name}`, message.substring(0, 100), req.user.id]
    );
    res.status(201).json({ success: true, message: "Sent." });
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed." });
  }
};

// ── CONTACT FORM ──────────────────────────────────────────────────────────────

const submitContact = async (req, res) => {
  try {
    const { name, email, subject, message } = req.body;
    if (!name || !email || !message)
      return res.status(400).json({ success: false, message: "Name, email, message required." });
    await db.execute("INSERT INTO contacts (name, email, subject, message) VALUES (?, ?, ?, ?)",
      [name, email, subject || null, message]);
    res.status(201).json({ success: true, message: "Message sent! We'll get back to you soon." });
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed." });
  }
};

// ── FEEDBACK ──────────────────────────────────────────────────────────────────

const submitFeedback = async (req, res) => {
  try {
    const { to_user_id, food_item_id, rating, comment, type } = req.body;
    if (!rating) return res.status(400).json({ success: false, message: "Rating required." });
    await db.execute(
      "INSERT INTO feedback (from_user_id, to_user_id, food_item_id, rating, comment, type) VALUES (?, ?, ?, ?, ?, ?)",
      [req.user.id, to_user_id || null, food_item_id || null, rating, comment || null, type || "platform"]
    );
    res.status(201).json({ success: true, message: "Feedback submitted. Thank you!" });
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed." });
  }
};

module.exports = {
  getDashboardStats, getAllUsers, toggleUserStatus, deleteUser, getAllFood, getReports, getContactMessages,
  getNotifications, markRead, markAllRead,
  getConversations, getMessages, sendMessage,
  submitContact, submitFeedback,
};
