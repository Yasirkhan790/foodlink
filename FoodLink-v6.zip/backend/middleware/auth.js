const jwt = require("jsonwebtoken");
const db = require("../config/db");

const authenticate = async (req, res, next) => {
  try {
    const header = req.headers.authorization;
    if (!header || !header.startsWith("Bearer "))
      return res.status(401).json({ success: false, message: "Authentication required." });

    const token = header.split(" ")[1];
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    const [rows] = await db.execute(
      "SELECT id, uuid, full_name, email, role, is_active FROM users WHERE id = ? AND is_active = 1",
      [decoded.id]
    );
    if (!rows.length)
      return res.status(401).json({ success: false, message: "User not found or deactivated." });

    req.user = rows[0];
    next();
  } catch (err) {
    return res.status(401).json({ success: false, message: "Invalid or expired token." });
  }
};

const authorize = (...roles) => (req, res, next) => {
  if (!roles.includes(req.user.role))
    return res.status(403).json({ success: false, message: `Access denied. Requires role: ${roles.join(" or ")}` });
  next();
};

module.exports = { authenticate, authorize };
