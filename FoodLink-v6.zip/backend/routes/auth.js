// routes/auth.js
const express = require("express");
const { body } = require("express-validator");
const { authenticate } = require("../middleware/auth");
const { upload } = require("../middleware/errorHandler");
const { register, login, getMe, updateProfile, changePassword } = require("../controllers/authController");

const router = express.Router();

router.post("/register", [
  body("full_name").trim().notEmpty().withMessage("Full name required"),
  body("email").isEmail().withMessage("Valid email required").normalizeEmail(),
  body("password").isLength({ min: 6 }).withMessage("Password must be at least 6 characters"),
  body("role").isIn(["donor","volunteer","recipient"]).withMessage("Invalid role"),
], register);

router.post("/login", [
  body("email").isEmail().normalizeEmail(),
  body("password").notEmpty(),
], login);

router.get("/me", authenticate, getMe);
router.put("/update-profile", authenticate, upload.single("profile_image"), updateProfile);
router.put("/change-password", authenticate, changePassword);

module.exports = router;
