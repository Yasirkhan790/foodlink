// routes/food.js
const express = require("express");
const { authenticate, authorize } = require("../middleware/auth");
const { upload } = require("../middleware/errorHandler");
const { create, getAll, getMine, getStats, getOne, update, remove } = require("../controllers/foodController");

const router = express.Router();

// Named routes BEFORE /:id
router.get("/mine",  authenticate, getMine);
router.get("/stats", authenticate, getStats);
router.get("/",      getAll);
router.post("/",     authenticate, authorize("donor"), upload.single("food_image"), create);
router.get("/:id",   getOne);
router.put("/:id",   authenticate, authorize("donor"), upload.single("food_image"), update);
router.delete("/:id",authenticate, authorize("donor", "admin"), remove);

module.exports = router;
