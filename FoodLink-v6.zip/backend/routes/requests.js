// routes/requests.js
const express = require("express");
const { authenticate, authorize } = require("../middleware/auth");
const {
  createRequest, getMyRequests, getAvailableRequests, getMyTasks,
  acceptTask, updateStatus, submitVerification, getFoodVerification,
  getMyDeliveries, getMySchedule,
} = require("../controllers/requestController");

const router = express.Router();

// Recipient
router.post("/",          authenticate, authorize("recipient"), createRequest);
router.get("/mine",       authenticate, authorize("recipient"), getMyRequests);

// Volunteer
router.get("/available",  authenticate, authorize("volunteer"), getAvailableRequests);
router.get("/my-tasks",   authenticate, authorize("volunteer"), getMyTasks);
router.put("/:id/accept", authenticate, authorize("volunteer"), acceptTask);
router.put("/:id/status", authenticate, updateStatus);

// Deliveries & Schedules
router.get("/deliveries/mine",  authenticate, authorize("volunteer"), getMyDeliveries);
router.get("/schedules/mine",   authenticate, authorize("volunteer"), getMySchedule);

// Verifications
router.post("/verifications",       authenticate, authorize("volunteer"), submitVerification);
router.get("/verifications/:id",    getFoodVerification);

module.exports = router;
