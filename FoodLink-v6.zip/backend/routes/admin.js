// routes/admin.js
const express = require("express");
const { authenticate, authorize } = require("../middleware/auth");
const {
  getDashboardStats, getAllUsers, toggleUserStatus, deleteUser, getAllFood, getReports, getContactMessages,
  getNotifications, markRead, markAllRead,
  getConversations, getMessages, sendMessage,
  submitContact, submitFeedback,
} = require("../controllers/adminController");

const router = express.Router();

// Admin-only
router.get("/stats",             authenticate, authorize("admin"), getDashboardStats);
router.get("/users",             authenticate, authorize("admin"), getAllUsers);
router.put("/users/:id/toggle",  authenticate, authorize("admin"), toggleUserStatus);
router.delete("/users/:id",      authenticate, authorize("admin"), deleteUser);
router.get("/food",              authenticate, authorize("admin"), getAllFood);
router.get("/reports",           authenticate, authorize("admin"), getReports);
router.get("/contacts",          authenticate, authorize("admin"), getContactMessages);

// Notifications (any authenticated)
router.get("/notifications",         authenticate, getNotifications);
router.put("/notifications/read-all",authenticate, markAllRead);
router.put("/notifications/:id/read",authenticate, markRead);

// Messages (any authenticated)
router.get("/messages/conversations",  authenticate, getConversations);
router.get("/messages/:userId",        authenticate, getMessages);
router.post("/messages",               authenticate, sendMessage);

// Public
router.post("/contact",  submitContact);
router.post("/feedback", authenticate, submitFeedback);

module.exports = router;
