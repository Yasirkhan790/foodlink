/**
 * FoodLink — Frontend API Client
 * Include on every page: <script src="api.js"></script>
 */

const API_BASE    = "http://localhost:5000/api";
const UPLOADS_URL = "http://localhost:5000";

// ── Session ───────────────────────────────────────────────────────────────────
const getToken = () => localStorage.getItem("fl_token");
const getUser  = () => { try { return JSON.parse(localStorage.getItem("fl_user")); } catch { return null; } };
const setSession = (token, user) => {
  localStorage.setItem("fl_token", token);
  localStorage.setItem("fl_user", JSON.stringify(user));
};
const clearSession = () => {
  localStorage.removeItem("fl_token");
  localStorage.removeItem("fl_user");
  localStorage.removeItem("fl_signup_temp");
};
const isLoggedIn = () => !!getToken() && !!getUser();

// ── Core Fetch ────────────────────────────────────────────────────────────────
async function apiRequest(endpoint, options = {}) {
  const token = getToken();
  const headers = { ...options.headers };
  if (!(options.body instanceof FormData)) headers["Content-Type"] = "application/json";
  if (token) headers["Authorization"] = `Bearer ${token}`;
  try {
    const res = await fetch(`${API_BASE}${endpoint}`, { ...options, headers });
    const data = await res.json();
    if (res.status === 401) { clearSession(); window.location.href = "login.html"; return; }
    return data;
  } catch (err) {
    console.error("API Error:", err);
    return { success: false, message: "Network error. Check your connection." };
  }
}

// ── AUTH ──────────────────────────────────────────────────────────────────────
const Auth = {
  async register(data) {
    return apiRequest("/auth/register", { method: "POST", body: JSON.stringify(data) });
  },
  async login(email, password, role) {
    const res = await apiRequest("/auth/login", {
      method: "POST", body: JSON.stringify({ email, password, role }),
    });
    if (res?.success) setSession(res.token, res.user);
    return res;
  },
  async getMe() { return apiRequest("/auth/me"); },
  async updateProfile(formData) {
    return apiRequest("/auth/update-profile", { method: "PUT", body: formData });
  },
  async changePassword(current_password, new_password) {
    return apiRequest("/auth/change-password", {
      method: "PUT", body: JSON.stringify({ current_password, new_password }),
    });
  },
  logout() { clearSession(); window.location.href = "login.html"; },
};

// ── FOOD ──────────────────────────────────────────────────────────────────────
const Food = {
  async getAll(params = {}) {
    const qs = new URLSearchParams(params).toString();
    return apiRequest(`/food${qs ? "?" + qs : ""}`);
  },
  async getOne(id) { return apiRequest(`/food/${id}`); },
  async getMine()  { return apiRequest("/food/mine"); },
  async getStats() { return apiRequest("/food/stats"); },
  async create(formData) {
    return apiRequest("/food", { method: "POST", body: formData });
  },
  async update(id, formData) {
    return apiRequest(`/food/${id}`, { method: "PUT", body: formData });
  },
  async remove(id) { return apiRequest(`/food/${id}`, { method: "DELETE" }); },
};

// ── REQUESTS ──────────────────────────────────────────────────────────────────
const Requests = {
  async create(data) {
    return apiRequest("/requests", { method: "POST", body: JSON.stringify(data) });
  },
  async getMine()         { return apiRequest("/requests/mine"); },
  async getAvailable()    { return apiRequest("/requests/available"); },
  async getMyTasks()      { return apiRequest("/requests/my-tasks"); },
  async acceptTask(id)    { return apiRequest(`/requests/${id}/accept`, { method: "PUT" }); },
  async updateStatus(id, status, notes) {
    return apiRequest(`/requests/${id}/status`, {
      method: "PUT", body: JSON.stringify({ status, notes }),
    });
  },
  async getMyDeliveries() { return apiRequest("/requests/deliveries/mine"); },
  async getMySchedule()   { return apiRequest("/requests/schedules/mine"); },
};

// ── VERIFICATIONS ─────────────────────────────────────────────────────────────
const Verify = {
  async submit(data) {
    return apiRequest("/requests/verifications", { method: "POST", body: JSON.stringify(data) });
  },
  async get(foodId) { return apiRequest(`/requests/verifications/${foodId}`); },
};

// ── NOTIFICATIONS ─────────────────────────────────────────────────────────────
const Notifications = {
  async getAll()       { return apiRequest("/notifications"); },
  async markRead(id)   { return apiRequest(`/notifications/${id}/read`, { method: "PUT" }); },
  async markAllRead()  { return apiRequest("/notifications/read-all", { method: "PUT" }); },
};

// ── MESSAGES ──────────────────────────────────────────────────────────────────
const Messages = {
  async getConversations() { return apiRequest("/messages/conversations"); },
  async getMessages(userId) { return apiRequest(`/messages/${userId}`); },
  async send(receiver_id, message, food_item_id = null) {
    return apiRequest("/messages", {
      method: "POST", body: JSON.stringify({ receiver_id, message, food_item_id }),
    });
  },
};

// ── ADMIN ─────────────────────────────────────────────────────────────────────
const Admin = {
  async getStats()    { return apiRequest("/stats"); },
  async getUsers(p = {}) {
    const qs = new URLSearchParams(p).toString();
    return apiRequest(`/users${qs ? "?" + qs : ""}`);
  },
  async toggleUser(id) { return apiRequest(`/users/${id}/toggle`, { method: "PUT" }); },
  async deleteUser(id) { return apiRequest(`/users/${id}`, { method: "DELETE" }); },
  async getFood(p = {}) {
    const qs = new URLSearchParams(p).toString();
    return apiRequest(`/food${qs ? "?" + qs : ""}`);
  },
  async getReports()  { return apiRequest("/reports"); },
  async getContacts() { return apiRequest("/contacts"); },
};

// ── CONTACT & FEEDBACK ────────────────────────────────────────────────────────
const Contact = {
  async submit(data) {
    return apiRequest("/contact", { method: "POST", body: JSON.stringify(data) });
  },
};
const Feedback = {
  async submit(data) {
    return apiRequest("/feedback", { method: "POST", body: JSON.stringify(data) });
  },
};

// ── GUARDS ────────────────────────────────────────────────────────────────────
function requireAuth(allowedRoles = []) {
  if (!isLoggedIn()) { window.location.href = "login.html"; return false; }
  const user = getUser();
  if (allowedRoles.length && !allowedRoles.includes(user.role)) {
    showToast("Access denied for your role.", "error");
    setTimeout(() => window.location.href = "login.html", 1500);
    return false;
  }
  return true;
}

function redirectIfLoggedIn() {
  if (!isLoggedIn()) return;
  const user = getUser();
  const map = {
    donor: "donor-dashboard.html",
    volunteer: "volunteer-dashboard.html",
    recipient: "recipient-dashboard.html",
    admin: "admin-dashboard.html",
  };
  window.location.href = map[user.role] || "index.html";
}

function getDashboardUrl(role) {
  const map = {
    donor: "donor-dashboard.html",
    volunteer: "volunteer-dashboard.html",
    recipient: "recipient-dashboard.html",
    admin: "admin-dashboard.html",
  };
  return map[role] || "index.html";
}

// ── TOAST ─────────────────────────────────────────────────────────────────────
function showToast(message, type = "success") {
  const existing = document.getElementById("fl-toast");
  if (existing) existing.remove();
  const colors = { success: "#2e8b57", error: "#ef4444", warning: "#f59e0b", info: "#3b82f6" };
  const icons  = { success: "check-circle", error: "exclamation-circle", warning: "exclamation-triangle", info: "info-circle" };
  const t = document.createElement("div");
  t.id = "fl-toast";
  t.style.cssText = `position:fixed;top:20px;right:20px;z-index:99999;padding:14px 22px;
    border-radius:12px;color:#fff;font-weight:600;font-size:14px;
    background:${colors[type] || colors.info};box-shadow:0 8px 24px rgba(0,0,0,0.2);
    display:flex;align-items:center;gap:10px;max-width:420px;
    animation:flToastIn 0.3s ease;pointer-events:none;`;
  t.innerHTML = `<i class="fas fa-${icons[type] || icons.info}"></i><span>${message}</span>`;
  document.body.appendChild(t);
  const style = document.createElement("style");
  style.textContent = "@keyframes flToastIn{from{opacity:0;transform:translateX(100px)}to{opacity:1;transform:translateX(0)}}";
  document.head.appendChild(style);
  setTimeout(() => t.remove(), 4000);
}

// ── LOAD NAV USER INFO ────────────────────────────────────────────────────────
function loadUserNav() {
  const user = getUser();
  if (!user) return;
  document.querySelectorAll(".user-name").forEach(el => el.textContent = user.name);
  document.querySelectorAll(".user-role").forEach(el => el.textContent = capitalise(user.role));
  document.querySelectorAll(".user-email").forEach(el => el.textContent = user.email);
  if (user.profile_image) {
    document.querySelectorAll(".user-avatar img,.avatar-img").forEach(el => {
      el.src = `${UPLOADS_URL}${user.profile_image}`;
    });
  }
  document.querySelectorAll(".avatar-initial,.user-initial").forEach(el => {
    el.textContent = user.name ? user.name.charAt(0).toUpperCase() : "?";
  });
}

function capitalise(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : ""; }

/**
 * Parse a MySQL DATETIME string (which is in server local time / UTC).
 * We append 'Z' only if the string has no timezone info so JS treats it as UTC.
 * Adjust if your server stores local time (remove the 'Z').
 */
function parseServerDate(date) {
  if (!date) return new Date();
  const s = String(date);
  // If already has timezone offset or 'Z', parse directly
  if (s.includes('Z') || s.includes('+') || s.includes('-', 10)) return new Date(s);
  // MySQL returns "2024-01-15 14:30:00" — treat as UTC
  return new Date(s.replace(' ', 'T') + 'Z');
}

function timeAgo(date) {
  const then = parseServerDate(date);
  const d = Math.floor((Date.now() - then.getTime()) / 1000);
  if (isNaN(d) || d < 0) return "just now";
  if (d < 60)   return d + "s ago";
  if (d < 3600) return Math.floor(d/60) + "m ago";
  if (d < 86400)return Math.floor(d/3600) + "h ago";
  return Math.floor(d/86400) + "d ago";
}

/**
 * Format a server timestamp as a readable local time string.
 * Shows time today, or date + time for older entries.
 */
function formatTime(date) {
  const then  = parseServerDate(date);
  if (isNaN(then.getTime())) return "—";
  const now   = new Date();
  const isToday = then.toDateString() === now.toDateString();
  const yesterday = new Date(now); yesterday.setDate(now.getDate() - 1);
  const isYesterday = then.toDateString() === yesterday.toDateString();
  const timeStr = then.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  if (isToday)     return `Today ${timeStr}`;
  if (isYesterday) return `Yesterday ${timeStr}`;
  return then.toLocaleDateString([], { day:'numeric', month:'short' }) + ' ' + timeStr;
}

document.addEventListener("DOMContentLoaded", loadUserNav);

// ── EXPORTS ───────────────────────────────────────────────────────────────────
window.FoodLink = {
  Auth, Food, Requests, Verify, Notifications, Messages, Admin, Contact, Feedback,
  getUser, isLoggedIn, requireAuth, redirectIfLoggedIn, getDashboardUrl,
  showToast, clearSession, UPLOADS_URL, timeAgo, formatTime, capitalise, loadUserNav,
};
window.UPLOADS_URL = UPLOADS_URL;
