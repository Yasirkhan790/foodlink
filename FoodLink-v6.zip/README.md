# FoodLink – Food Security & Community Welfare Platform
## KUST BSCS FYP Group 53 — Yasir Khan, Muhammad Bilal, Munsif Khan
## Supervisor: Mr. Sajid Ullah

---

## 🚀 Setup Instructions

### 1. Install Dependencies
```bash
cd backend
npm install
```

### 2. Configure Environment
Edit `backend/.env`:
```env
PORT=5000
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_mysql_password    # leave blank if no password
DB_NAME=foodlink_db
JWT_SECRET=foodlink_jwt_secret_2024
ADMIN_EMAIL=admin@foodlink.com
ADMIN_PASSWORD=Admin@123456
FRONTEND_URL=http://127.0.0.1:5500
```

### 3. Setup Database (creates DB + all tables + admin user)
```bash
npm run setup
```

### 4. Start the Server
```bash
npm run dev     # development (auto-restart)
npm start       # production
```
Server runs on: http://localhost:5000
Health check: http://localhost:5000/api/health

### 5. Open Frontend
Open `backend/frontend/index.html` with **VS Code Live Server** (right-click → Open with Live Server)
OR open directly in browser: `file:///path/to/backend/frontend/index.html`

---

## 👤 Test Accounts

| Role      | Email                    | Password      |
|-----------|--------------------------|---------------|
| Admin     | admin@foodlink.com       | Admin@123456  |
| Donor     | Register at signup.html  | your choice   |
| Volunteer | Register at signup.html  | your choice   |
| Recipient | Register at signup.html  | your choice   |

---

## 📁 Project Structure

```
foodlink/
├── backend/
│   ├── config/
│   │   ├── db.js           # MySQL pool connection
│   │   └── setup.js        # DB creation + seeding
│   ├── controllers/
│   │   ├── authController.js
│   │   ├── foodController.js
│   │   ├── requestController.js
│   │   └── adminController.js
│   ├── middleware/
│   │   ├── auth.js         # JWT authenticate + authorize
│   │   └── errorHandler.js # Multer + error handling
│   ├── routes/
│   │   ├── auth.js
│   │   ├── food.js
│   │   ├── requests.js
│   │   └── admin.js
│   ├── uploads/            # Food images stored here
│   ├── frontend/
│   │   ├── api.js                      # Frontend API client
│   │   ├── index.html                  # Landing page
│   │   ├── login.html                  # Login (all roles)
│   │   ├── signup.html                 # Quick signup
│   │   ├── donor-registration.html     # Detailed donor signup
│   │   ├── volunteer-registration.html # Detailed volunteer signup
│   │   ├── donor-dashboard.html        # Donor home
│   │   ├── volunteer-dashboard.html    # Volunteer hub
│   │   ├── recipient-dashboard.html    # Recipient tracker
│   │   ├── admin-dashboard.html        # Admin panel
│   │   ├── admin-login.html            # Admin login
│   │   ├── donate-food.html            # Post food form
│   │   ├── available-food.html         # Browse + request food
│   │   ├── food-safety.html            # Safety checklist
│   │   ├── notifications.html          # Alerts
│   │   ├── messages.html               # Chat
│   │   ├── profile.html                # Edit profile
│   │   ├── settings.html               # Preferences
│   │   ├── reports.html                # Analytics
│   │   ├── schedule.html               # Volunteer schedule
│   │   ├── tracking.html               # Delivery tracking
│   │   ├── about.html                  # About + team
│   │   └── contact.html                # Contact form
│   ├── .env
│   ├── server.js
│   └── package.json
```

---

## 🗄️ Database Tables

| Table         | Purpose                              |
|---------------|--------------------------------------|
| users         | All users (donor/volunteer/recipient/admin) |
| food_items    | Food donations with expiry/photo     |
| requests      | Recipient food requests              |
| deliveries    | Volunteer delivery records           |
| verifications | Food safety checklist results        |
| notifications | System alerts per user               |
| messages      | Chat messages between users          |
| feedback      | Ratings and reviews                  |
| contacts      | Public contact form submissions      |
| schedules     | Volunteer pickup schedules           |

---

## 🔌 API Endpoints

### Auth
- POST /api/auth/register
- POST /api/auth/login
- GET  /api/auth/me
- PUT  /api/auth/update-profile
- PUT  /api/auth/change-password

### Food
- GET  /api/food (public)
- GET  /api/food/mine (donor)
- GET  /api/food/stats
- GET  /api/food/:id
- POST /api/food (donor)
- PUT  /api/food/:id (donor)
- DELETE /api/food/:id

### Requests
- POST /api/requests (recipient)
- GET  /api/requests/mine
- GET  /api/requests/available (volunteer)
- GET  /api/requests/my-tasks (volunteer)
- PUT  /api/requests/:id/accept (volunteer)
- PUT  /api/requests/:id/status
- GET  /api/requests/deliveries/mine
- GET  /api/requests/schedules/mine
- POST /api/requests/verifications
- GET  /api/requests/verifications/:id

### Admin
- GET  /api/stats
- GET  /api/users
- PUT  /api/users/:id/toggle
- DELETE /api/users/:id
- GET  /api/reports
- GET  /api/contacts

### Notifications & Messages
- GET  /api/notifications
- PUT  /api/notifications/read-all
- PUT  /api/notifications/:id/read
- GET  /api/messages/conversations
- GET  /api/messages/:userId
- POST /api/messages
- POST /api/contact (public)
- POST /api/feedback
